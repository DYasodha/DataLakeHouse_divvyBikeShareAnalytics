# Databricks notebook source
# MAGIC %fs ls /FileStore/tables/

# COMMAND ----------

# Bronze Layer Extraction
path = "/FileStore/tables/"

# 1. TRIPS
df_trips = spark.read.format("csv") \
    .option("header", "false") \
    .option("inferSchema", "true") \
    .load(f"{path}trips.csv") \
    .toDF("trip_id", "rideable_type", "start_at", "end_at", "start_station_id", "end_station_id", "rider_id")
df_trips.write.format("delta").mode("overwrite").save("/mnt/delta/bronze_trips")

# 2. RIDERS
df_riders = spark.read.format("csv") \
    .option("header", "false") \
    .option("inferSchema", "true") \
    .load(f"{path}riders.csv") \
    .toDF("rider_id", "first_name", "last_name", "address", "birthday", "account_start", "account_end", "is_member")
df_riders.write.format("delta").mode("overwrite").save("/mnt/delta/bronze_riders")

# 3. STATIONS
df_stations = spark.read.format("csv") \
    .option("header", "false") \
    .option("inferSchema", "true") \
    .load(f"{path}stations.csv") \
    .toDF("station_id", "name", "latitude", "longitude")
df_stations.write.format("delta").mode("overwrite").save("/mnt/delta/bronze_stations")

# 4. PAYMENTS
df_payments = spark.read.format("csv") \
    .option("header", "false") \
    .option("inferSchema", "true") \
    .load(f"{path}payments.csv") \
    .toDF("payment_id", "date", "amount", "rider_id")
df_payments.write.format("delta").mode("overwrite").save("/mnt/delta/bronze_payments")

# COMMAND ----------

# load step (silver layer)
spark.sql("CREATE TABLE IF NOT EXISTS staging_trips USING DELTA LOCATION '/mnt/delta/bronze_trips'")
spark.sql("CREATE TABLE IF NOT EXISTS staging_riders USING DELTA LOCATION '/mnt/delta/bronze_riders'")
spark.sql("CREATE TABLE IF NOT EXISTS staging_stations USING DELTA LOCATION '/mnt/delta/bronze_stations'")
spark.sql("CREATE TABLE IF NOT EXISTS staging_payments USING DELTA LOCATION '/mnt/delta/bronze_payments'")

# COMMAND ----------

# Tranformation step  (dimension tables)
# 1. Dimension: Riders (Updated account_start)
spark.sql("""
CREATE TABLE IF NOT EXISTS dim_rider
USING DELTA
AS SELECT 
    rider_id, 
    first_name, 
    last_name, 
    address, 
    birthday, 
    account_start, 
    is_member
FROM staging_riders
""")

# 2. Dimension: Stations (No changes needed)
spark.sql("""
CREATE TABLE IF NOT EXISTS dim_station
USING DELTA
AS SELECT 
    station_id, name, latitude, longitude
FROM staging_stations
""")

# 3. Dimension: Date
spark.sql("""
CREATE TABLE IF NOT EXISTS dim_date
USING DELTA
AS SELECT 
    start_at as date_id,
    date(start_at) as full_date,
    dayofweek(start_at) as day_of_week,
    month(start_at) as month,
    quarter(start_at) as quarter,
    year(start_at) as year
FROM staging_trips
UNION
SELECT 
    date as date_id,
    date(date) as full_date,
    dayofweek(date) as day_of_week,
    month(date) as month,
    quarter(date) as quarter,
    year(date) as year
FROM staging_payments
""")

# COMMAND ----------


from pyspark.sql.functions import col, unix_timestamp, year

# Load staging data
trips = spark.table("staging_trips")
riders = spark.table("staging_riders")
dates = spark.table("dim_date")
stations = spark.table("dim_station")

# 4. Fact: Trips (Explicit joins as requested by reviewer)
fact_trip = trips.alias("t") \
    .join(riders.alias("r"), "rider_id") \
    .join(dates.alias("d"), col("t.start_at") == col("d.date_id")) \
    .join(stations.alias("ss"), col("t.start_station_id") == col("ss.station_id")) \
    .join(stations.alias("es"), col("t.end_station_id") == col("es.station_id")) \
    .select(
        col("t.trip_id"),
        col("t.rider_id"),
        col("t.start_station_id"),
        col("t.end_station_id"),
        col("d.date_id"),
        ((unix_timestamp("t.end_at") - unix_timestamp("t.start_at")) / 60).alias("duration"),
        (year("t.start_at") - year("r.birthday")).alias("rider_age")
    )

fact_trip.write.format("delta").mode("overwrite").saveAsTable("fact_trip")

# 5. Fact: Payments
fact_payment = spark.table("staging_payments").alias("p") \
    .join(dates.alias("d"), col("p.date") == col("d.date_id")) \
    .select(
        col("p.payment_id"),
        col("p.rider_id"),
        col("d.date_id"),
        col("p.amount")
    )

fact_payment.write.format("delta").mode("overwrite").saveAsTable("fact_payment")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check all tables in your current database
# MAGIC SHOW TABLES;
# MAGIC
# MAGIC -- Verify the columns in your Fact Table
# MAGIC DESCRIBE TABLE fact_trip;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     trip_id, 
# MAGIC     duration, 
# MAGIC     rider_age 
# MAGIC FROM fact_trip 
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     t.trip_id,
# MAGIC     s_start.name AS start_station,
# MAGIC     s_end.name AS end_station,
# MAGIC     d.year,
# MAGIC     d.month,
# MAGIC     t.duration
# MAGIC FROM fact_trip t
# MAGIC JOIN dim_station s_start ON t.start_station_id = s_start.station_id
# MAGIC JOIN dim_station s_end ON t.end_station_id = s_end.station_id
# MAGIC JOIN dim_date d ON t.date_id = d.date_id
# MAGIC LIMIT 10;

# COMMAND ----------

# Run this in a Python cell
staging_count = spark.table("staging_trips").count()
fact_count = spark.table("fact_trip").count()

print(f"Staging Rows: {staging_count}")
print(f"Fact Rows: {fact_count}")

if staging_count == fact_count:
    print("Verification Successful: No data lost!")
else:
    print("Warning: Row counts do not match.")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check all tables in your current database
# MAGIC SHOW TABLES;

# COMMAND ----------

